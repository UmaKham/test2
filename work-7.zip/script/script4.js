/* let month = +prompt("Введите месяц используя число")

if (month >= 6 && month <= 8) {
  alert(`Это лето`)
} else if (month >= 9 && month <=11) {
  alert(`Это осень`)
} else if (month == 12 || month >= 0 && month <= 2) {
  alert(`Это зима`)
} else if (month >= 3 && month <= 5) {
  alert(`Это весна`)
} else {
  alert(`Вы не выбрали месяц`)
} */