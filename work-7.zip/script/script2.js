/* let number = +prompt("Введите любое число")

if (number % 2 == 0) {
  alert("Четное число")
} else {
  alert("Нечетное число")
} */