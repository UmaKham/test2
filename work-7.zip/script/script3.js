/* let numberOne = +prompt("Введите первое число")
let numberTwo = +prompt("Введите второе число")
let operator = prompt("Выберите действие + - * /")

if (operator == "+") {
  alert(numberOne + numberTwo)
} else if (operator == "-") {
  alert(numberOne - numberTwo)
} else if (operator == "*") {
  alert(numberOne * numberTwo)
} else if (operator == "/") {
  alert(numberOne / numberTwo)
} else {
  alert ("Error")
} */